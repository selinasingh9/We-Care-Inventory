from datetime import datetime

def save_product_data(product_list):
    """Writes the updated product list back to the file"""
    try:
        file = open("products.txt", "w")
        for product in product_list:
            line = product[0] + "," + product[1] + "," + str(product[2]) + "," + str(product[3]) + "," + product[4] + "\n"
            file.write(line)
        file.close()
    except Exception as error:
        print("Error saving data:", error)

def generate_bill_file(buyer_name, purchased_items, is_purchase):
    time_now = datetime.now()
    bill_file = "bill_" + time_now.strftime("%Y%m%d_%H%M%S") + ".txt"
    
    # Build bill content
    bill_lines = [
        "\n\tPRODUCT WHOLESALE SYSTEM",
        "\t--------------------------",
        "Date: " + str(time_now),
        "Customer: " + buyer_name,
        "Type: " + ("Purchase" if is_purchase else "Sale"),
        "\nItem(s):"
    ]
    
    total_price = 0
    for item in purchased_items:
        item_total = item["qty"] * item["price"]
        bill_lines.append("\t" + item["name"] + " (" + item["brand"] + ")")
        bill_lines.append("\tQty: " + str(item["qty"]) + " x Rs." + str(item["price"]) + 
                         " = Rs." + str(item_total))
        total_price += item_total
    
    bill_lines.append("\nTOTAL: Rs." + str(total_price))

    # Print to screen
    print("\n" + "\n".join(bill_lines) + "\n")
    
    # Save to file
    with open(bill_file, "w") as file:
        file.write("\n".join(bill_lines))
    
    print("Bill saved as: " + bill_file)
