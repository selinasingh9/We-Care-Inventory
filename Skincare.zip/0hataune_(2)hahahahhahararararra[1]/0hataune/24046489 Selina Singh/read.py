def read_product_data():
    """Reads products from file into a list"""
    product_list = []
    try:
        file = open("products.txt", "r")
        for line in file:
            if line != "" and line != "\n":
                parts = line.replace("\n", "").split(",")
                if len(parts) == 5:
                    product_list.append([
                        parts[0],
                        parts[1],
                        int(parts[2]),
                        int(parts[3]),
                        parts[4]
                    ])
        file.close()
    except Exception as error:
        print("Error reading file:", error)
    return product_list
