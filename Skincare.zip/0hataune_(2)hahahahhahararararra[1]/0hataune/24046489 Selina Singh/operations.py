def save_product_data(product_list):
    """Writes the updated product list back to products.txt"""
    try:
        with open("products.txt", "w") as file:
            for product in product_list:
                line = ",".join([
                    product[0],  # name
                    product[1],  # brand
                    str(product[2]),  # quantity
                    str(product[3]),  # price
                    product[4]   # country
                ]) + "\n"
                file.write(line)
    except Exception as e:
        print("Error saving product data:", e)

def show_products(product_list):
    """Displays full product names in clean tables using basic operations"""
    print("\nID  NAME                     BRAND                QTY    PRICE    COUNTRY")
    print("-----------------------------------------------------------------------")
    
    for i in range(len(product_list)):
        product = product_list[i]
        # Prepare each column
        id_str = str(i+1)
        id_str = id_str if len(id_str) > 1 else " " + id_str  # 2-digit align
        
        # Name column (24 chars, full words)
        name = product[0]
        name_spaces = 24 - len(name)
        name = name + (" " * name_spaces) if name_spaces > 0 else name[:24]
        
        # Brand column (18 chars, full words)
        brand = product[1]
        brand_spaces = 18 - len(brand)
        brand = brand + (" " * brand_spaces) if brand_spaces > 0 else brand[:18]
        
        # Qty column (5 chars, right-aligned)
        qty = str(product[2])
        qty = (" " * (5 - len(qty))) + qty
        
        # Price column (8 chars with Rs.)
        price = "Rs." + str(product[3])
        price = price + (" " * (8 - len(price)))
        
        # Combine all columns
        print(id_str + "  " + name + " " + brand + " " + qty + "  " + price + " " + product[4])

def purchase_products(product_list):
    buyer_name = input("Enter buyer name: ")
    cart = []

    while True:
        show_products(product_list)
        product_input = input("Enter product ID to purchase (or '0' to finish): ")

        if product_input == "0":
            if len(cart) == 0:
                print("No items purchased. Returning to main menu...")
                return None, None
            break

        try:
            product_id = int(product_input)
            if product_id < 1 or product_id > len(product_list):
                print("Invalid ID. Please enter a number between 1 and", len(product_list))
                continue
        except ValueError:
            print("Please enter a valid number!")
            continue

        try:
            quantity_input = input("Enter quantity to purchase: ")
            quantity = int(quantity_input)
            if quantity < 1:
                print("Quantity must be at least 1")
                continue
        except ValueError:
            print("Please enter a valid quantity!")
            continue

        product = product_list[product_id - 1]
        free_items = quantity // 3
        total_required = quantity + free_items

        if total_required > product[2]:
            print("Not enough stock! Available:", product[2], "Required:", total_required)
            continue

        selling_price = product[3] * 2
        subtotal = selling_price * quantity
        
        cart.append({
            "name": product[0],
            "brand": product[1],
            "qty": quantity,
            "free": free_items,
            "price": selling_price,
            "subtotal": subtotal
        })

        product[2] -= total_required
        print("Added", quantity, product[0], "to cart (with", free_items, "free items)")

    # Calculate billing details
    subtotal = sum(item["subtotal"] for item in cart)
    vat = round(subtotal * 0.13, 2)  # 13% VAT rounded to 2 decimal places
    total = subtotal + vat

    # Display purchase summary in clean format
    print("\n===== PURCHASE SUMMARY =====")
    print("Customer:", buyer_name)
    print("\nITEMS PURCHASED:")
    for item in cart:
        print("Product:", item["name"])
        print("Brand:", item["brand"])
        print("Quantity Purchased:", item["qty"])
        print("Free Items:", item["free"])
        print("Unit Price: Rs." + str(item["price"]))
        print("--------------------------------")
    print("Subtotal: Rs." + str(subtotal))
    print("VAT (13%): Rs." + str(vat))
    print("Total Cost: Rs." + str(total))
    print("============================")

    # Generate bill file
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = "purchase_" + buyer_name.replace(" ", "_") + "_" + timestamp + ".txt"
    
    with open(filename, "w") as file:
        file.write("===== PURCHASE INVOICE =====\n")
        file.write("Date: " + str(datetime.now()) + "\n")
        file.write("Customer: " + buyer_name + "\n")
        file.write("\nITEMS PURCHASED:\n")
        for item in cart:
            file.write("Product: " + item["name"] + "\n")
            file.write("Brand: " + item["brand"] + "\n")
            file.write("Quantity Purchased: " + str(item["qty"]) + "\n")
            file.write("Free Items: " + str(item["free"]) + "\n")
            file.write("Unit Price: Rs." + str(item["price"]) + "\n")
            file.write("--------------------------------\n")
        file.write("Subtotal: Rs." + str(subtotal) + "\n")
        file.write("VAT (13%): Rs." + str(vat) + "\n")
        file.write("Total Cost: Rs." + str(total) + "\n")
        file.write("============================\n")

    print("\nInvoice saved as", filename)
    save_product_data(product_list)
    
    return buyer_name, cart

def restock_products(product_list):
    show_products(product_list)
    product_input = input("Enter product ID to restock: ")

    try:
        product_id = int(product_input)
        if product_id < 1 or product_id > len(product_list):
            print("Invalid product ID")
            return
    except:
        print("Enter a valid number")
        return

    quantity_input = input("Enter quantity to add: ")

    try:
        quantity = int(quantity_input)
        if quantity < 1:
            print("Invalid quantity")
            return
    except:
        print("Invalid input")
        return

    # Get the product being restocked
    product = product_list[product_id - 1]
    
    # Calculate restock details
    restock_cost = product[3] * quantity  # Original price * quantity
    
    vat = restock_cost * 0.13  # 13% VAT
    total = restock_cost + vat
    
    # Update stock
    product[2] = product[2] + quantity
    
    # Display restock bill
    print("\n===== RESTOCK INVOICE =====")
    print("Product: " + product[0])
    print("Brand: " + product[1])
    print("Quantity Added: " + str(quantity))
    print("Unit Cost: Rs." + str(product[3]))
    print("--------------------------------")
    print("Subtotal: Rs." + str(restock_cost))
    print("VAT (13%): Rs." + str(vat))
    print("Total Cost: Rs." + str(total))
    print("============================")
    
    # Generate bill file
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    product_name = product[0].replace(" ", "_")
    filename = "restock_" + product_name + "_" + timestamp + ".txt"
    
    with open(filename, "w") as file:
        file.write("===== RESTOCK INVOICE =====\n")
        file.write("Date: " + str(datetime.now()) + "\n")
        file.write("Product: " + product[0] + "\n")
        file.write("Brand: " + product[1] + "\n")
        file.write("Quantity Added: " + str(quantity) + "\n")
        file.write("Unit Cost: Rs." + str(product[3]) + "\n")
        file.write("--------------------------------\n")
        file.write("Subtotal: Rs." + str(restock_cost) + "\n")
        file.write("VAT (13%): Rs." + str(vat) + "\n")
        file.write("Total Cost: Rs." + str(total) + "\n")
        file.write("============================\n")
    
    print("Stock updated!")
    print("Restock invoice saved as: " + filename)
    save_product_data(product_list)

# Main program loop
def main():
    # Load product data without using strip()
    try:
        with open("products.txt", "r") as file:
            product_list = []
            for line in file:
                # Remove newline character by slicing
                if line.endswith('\n'):
                    line = line[:-1]
                product = line.split(",")
                # Convert quantity and price to integers
                product[2] = int(product[2])  # quantity
                product[3] = int(product[3])  # price
                product_list.append(product)
    except FileNotFoundError:
        print("Error: products.txt not found!")
        return
    except Exception as e:
        print("Error loading product data:", e)
        return

    while True:
        print("\n===== STORE MANAGEMENT SYSTEM =====")
        print("1. Show Products")
        print("2. Purchase Products")
        print("3. Restock Products")
        print("4. Exit")
        
        choice = input("Enter your choice (1-4): ")
        
        if choice == "1":
            show_products(product_list)
        elif choice == "2":
            purchase_products(product_list)
        elif choice == "3":
            restock_products(product_list)
        elif choice == "4":
            print("Exiting program...")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")

if __name__ == "__main__":
    main()
