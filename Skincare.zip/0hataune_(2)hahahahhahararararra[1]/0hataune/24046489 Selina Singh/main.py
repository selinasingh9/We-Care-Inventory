# main.py
# Entry point for the Product Wholesale System (Milestone 2)
# Handles the user menu and calls appropriate operations based on user input

from read import read_product_data
from write import save_product_data, generate_bill_file
from operations import show_products, purchase_products, restock_products

def show_menu():
    """
    Displays the main menu options for the user.
    """
    print("\n====== We Care Inventory ======")
    print("1. Sell Product")
    print("2. Restock Product")
    print("3. View Products")
    print("4. Exit")

def run_program():
    """
    Main loop of the program that manages user interactions and system operations.
    Reads product data, shows menu, and handles user choices for selling, restocking,
    viewing inventory, and exiting the system.
    """
    products = read_product_data()  # Load product data from file at the start

    while True:
        show_menu()  # Display menu to user
        option = input("Choose option (1-4): ")  # Get user input

        # Option 1: Sell products
        if option == "1":
            buyer, items = purchase_products(products)
            if items:  # Check if items is not None and not empty
                generate_bill_file(buyer, items, False)  # Generate and save bill for purchase
            save_product_data(products)  # Save changes after purchase attempt

        # Option 2: Restock products
        elif option == "2":
            restock_products(products)
            save_product_data(products)  # Save changes after restock

        # Option 3: View current inventory
        elif option == "3":
            show_products(products)

        # Option 4: Exit and save changes
        elif option == "4":
            save_product_data(products)  # Save updated inventory back to file
            print("Goodbye!")
            break  # Exit the program

        # Handle invalid menu choices
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")

# Start the program
if __name__ == "__main__":
    run_program()
